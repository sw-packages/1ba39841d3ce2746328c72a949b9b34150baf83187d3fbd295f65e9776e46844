#ifndef SIMDJSON_HASWELL_H
#define SIMDJSON_HASWELL_H

#include "simdjson/haswell/begin.h"
#include "simdjson/generic/amalgamated.h"
#include "simdjson/haswell/end.h"

#endif // SIMDJSON_HASWELL_H